import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
    int op;

        Scanner scanner = new Scanner(System.in);

        System.out.println("1-Depositar na Conta Básica");
        System.out.println("2-Sacar da Conta Básica");
        System.out.println("3-Transferir da Conta Básica para a Conta Premium");
        System.out.println("4-Depositar na Conta Premium");
        System.out.println("5-Sacar da Conta Premium");
        System.out.println("6-Transferir da Conta Premium para a Conta Básica");
        System.out.println("7-Mostrar Saldo");
        System.out.println("8-Sair");

        op = scanner.nextInt();

        switch(op){

            case 1:
                System.out.println("1-Depositar na Conta Básica");
                break;
            case 2:
                System.out.println("2-Sacar da Conta Básica");
                break;
            case 3:
                System.out.println("3-Transferir da Conta Básica para a Conta Premium");
                break;
            case 4:
                System.out.println("4-Depositar na Conta Premium");
                break;
            case 5:
                System.out.println("5-Sacar da Conta Premium");
                break;
            case 6:
                System.out.println("6-Transferir da Conta Premium para a Conta Básica");
                break;
            case 7:
                System.out.println("7-Mostrar Saldo");
                break;
            case 8:
                System.out.println("8-Sair");
                break;

        }
    }


}
