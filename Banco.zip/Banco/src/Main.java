import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws Exception {
    int op;
    float dinheiro;
    String nome;

        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o nome do titular");
        nome = scanner.next();

    Conta minhaContaBasica = new ContaBasica(nome);
    Conta minhaContaPremium = new ContaPremium(nome);

        do {
    System.out.println("Olá " + minhaContaBasica.getTitular() + " Escolha uma das opções abaixo: ");
    System.out.println("1-Depositar na Conta Básica");
    System.out.println("2-Sacar da Conta Básica");
    System.out.println("3-Transferir da Conta Básica para a Conta Premium");
    System.out.println("4-Depositar na Conta Premium");
    System.out.println("5-Sacar da Conta Premium");
    System.out.println("6-Transferir da Conta Premium para a Conta Básica");
    System.out.println("7-Mostrar Saldo");
    System.out.println("8-Sair");
    op = scanner.nextInt();

    switch (op) {

        case 1:
                System.out.println("1-Depositar na Conta Básica");
                System.out.println("Insira o valor do deposito");
                dinheiro = scanner.nextFloat();
                minhaContaBasica.depositar(dinheiro);
                System.out.print("Saldo da conta basica do titular"+ minhaContaBasica.getTitular()+" após o deposito: " + minhaContaBasica.getSaldo());
            break;
            
        case 2:
            try {
                System.out.println("2-Sacar da Conta Básica");
                System.out.println("Insira o valor do saque");
                dinheiro = scanner.nextFloat();
                minhaContaBasica.sacar(dinheiro);
                System.out.println();
                System.out.print("Saldo da conta basica" + minhaContaBasica.getTitular()+ "após o saque: " + minhaContaBasica.getSaldo());
            }catch (Exception e) {
                System.out.println(e.getMessage());
            }
            break;

        case 3:
            try {
                System.out.println("3-Transferir da Conta Básica para a Conta Premium");
                System.out.println("Insira o valor que quer tansferir");
                dinheiro = scanner.nextFloat();
                minhaContaBasica.sacar(dinheiro);
                minhaContaPremium.depositar(dinheiro);
                System.out.println("Saldos da conta do titular após a transferencia"+ minhaContaBasica.getTitular());
                System.out.println("Saldo da conta premium após a transferencia: " + minhaContaPremium.getSaldo());
                System.out.println("Saldo da conta basica após a transferencia: " + minhaContaBasica.getSaldo());
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            break;

        case 4:
            System.out.println("4-Depositar na Conta Premium");
            System.out.println("Insira o valor do deposito");
            dinheiro = scanner.nextFloat();
            minhaContaPremium.depositar(dinheiro);
            System.out.print("Saldo da conta premium"+minhaContaBasica.getTitular()+ "após o deposito: " + minhaContaPremium.getSaldo());
            System.out.println();
            break;

        case 5:
            System.out.println("5-Sacar da Conta Premium");
            try {
                System.out.println("Insira o valor do saque");
                dinheiro = scanner.nextFloat();
                minhaContaPremium.sacar(dinheiro);
                System.out.println();
                System.out.print("Saldo da conta premium do titular" + minhaContaBasica.getTitular() + "após o saque: " + minhaContaPremium.getSaldo());
            }catch (Exception e) {
                System.out.println(e.getMessage());
            }
            break;

        case 6:
            System.out.println("6-Transferir da Conta Premium para a Conta Básica");
            try {
                System.out.println("Insira o valor que quer tansferir");
                dinheiro = scanner.nextFloat();
                minhaContaPremium.sacar(dinheiro);
               minhaContaBasica.depositar(dinheiro);
                System.out.println("Saldos da conta do titular após a transferencia"+ minhaContaBasica.getTitular());
                System.out.println("Saldo da conta basica após a transferencia: " + minhaContaBasica.getSaldo());
                System.out.println("Saldo da conta premium após a transferencia: " + minhaContaPremium.getSaldo());
            }catch (Exception e){
                System.out.println(e.getMessage());
            }
            break;

        case 7:
            System.out.println("7-Mostrar Saldo");
            System.out.println("Saldos da conta do titular"+ minhaContaBasica.getTitular());
            System.out.println("Saldo da conta basica: " + minhaContaBasica.getSaldo());
            System.out.println("Saldo da conta premium: " + minhaContaPremium.getSaldo());
            System.out.println();
            break;

        case 8:
            System.out.println("Saindo do sistema");
            System.exit(0);
            break;
    }
}while (op <= 8 && op > 0);
        if(op > 8 || op < 1) {
            System.out.println("ERRO, você digitou um número invalido");
        }
    }
}
