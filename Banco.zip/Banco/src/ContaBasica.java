public class ContaBasica extends Conta{
    public ContaBasica(String titular) {
        super(titular);
    }

    public static void main(String[] args) {



        }
    @Override
    public void depositar(double valor) throws Exception {
        if (valor > 0){
            //saldo += valor;
            saldo = saldo + valor;
        }
    }

    @Override
    public void sacar(double valor) throws Exception {
        if (valor > saldo){
            throw new Exception("Saldo insuficiente para realizar o saque.");
        } else if (valor < saldo){
            saldo = saldo - valor;
        }
    }

}
